#include<stdio.h> 
#include <stdlib.h>

typedef struct node{
	int val; 
	struct node *next; 
}Node;

Node *head=NULL;

// Function to add node to original list
int add_node(int val){

	Node *temp=(Node*)malloc(sizeof(Node));
	temp->next=NULL; 
	temp->val=val; 

	if(head==NULL){
		head=temp; 
	}
	else {
		Node *cur=head; 
		while(cur->next!=NULL){
			cur=cur->next; 
		}
		cur->next=temp;
	}
}

Node * Copy_Link_List(Node *orig_head){

	if(orig_head==NULL)
	    return NULL; 

	Node *new_head=orig_head;
	Node *new_tail=orig_head;

	Node *cur=orig_head;
	while(cur!=NULL){
	Node *temp=(Node *)malloc(sizeof(Node));
	     temp->next=NULL; 
     	     temp->val=orig_head->val;
	
	     if(new_head==NULL){
	      new_head=temp; 
	      new_tail=temp; 
	      }
	     else {
	    new_tail->next=temp; 
	    new_tail=temp; 
	     }
	    cur=cur->next;  
	}
	return new_head;
}

int print_Node(){

	Node *cur=head;
	printf("\n in Print_Node function ...\n");

	if(cur==NULL){
	printf("\n  List is Empty  ...\n");
	}
	int count=0; 

	while(cur!=NULL){
	printf(" Count =%d..Node=%d\n",count++, cur->val);
	cur=cur->next;
	}
	return 0; 
}

int main(){

	printf("\n in main function ...\n");
	for(int i=10; i<100; i+=10){
	printf("\n in loopmain function ...\n");
	add_node(i);
	}

	Node *New_list=Copy_Link_List(head);


	while(New_list!=NULL){ 
	printf(" Count =%d..Node=%d\n",count++, cur->val);
	cur=cur->next;
	}
	//print_Node();
	return 0; 
}
